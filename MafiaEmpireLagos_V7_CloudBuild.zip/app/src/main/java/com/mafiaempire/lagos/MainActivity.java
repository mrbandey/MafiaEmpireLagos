package com.mafiaempire.lagos;
import android.app.*;import android.os.*;import android.webkit.*;import android.graphics.Color;import android.view.*;
public class MainActivity extends Activity{
 public void onCreate(Bundle b){super.onCreate(b);getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
 WebView w=new WebView(this);w.setBackgroundColor(Color.BLACK);WebSettings s=w.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);w.setWebViewClient(new WebViewClient());w.loadUrl("file:///android_asset/game.html");setContentView(w);}
}